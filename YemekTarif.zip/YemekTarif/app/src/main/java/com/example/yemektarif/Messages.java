package com.example.yemektarif;

public  class Messages {
    public  static String kayıtBasarı="Kayıt Başarıyla Gerçekleşti";
    public  static String kayıtHata="Hata!Kayıt Gerçekleşmedi";
    public  static String mailBasarı="Mailinizi Kontrol Ediniz";
    public  static String mailHata="Hata! Tekrar Deneyiniz";
    public  static String  girisBasarı="Giriş Başarılı";
    public  static String girisHata="E-posta adresiniz ve/veya şifreniz hatalı.";
}
