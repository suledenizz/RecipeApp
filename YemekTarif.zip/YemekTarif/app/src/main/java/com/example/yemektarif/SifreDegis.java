package com.example.yemektarif;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class SifreDegis extends AppCompatActivity {
    ImageButton kategori, blog, kaydettarif, bilgiler;
    EditText güncelSifre,yeniSifre ,yeniSifreTekrar;
    ImageButton sifreDegistir;
    FirebaseAuth firebaseAuth;

    FirebaseUser user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sifre_degis);
        firebaseAuth = FirebaseAuth.getInstance();
        user = firebaseAuth.getCurrentUser();
        blog=findViewById(R.id.blog_sifredegis);
        kaydettarif=findViewById(R.id.tarifler_sifredegis);
        bilgiler=findViewById(R.id.bilgiler_sifredegis);
        güncelSifre=findViewById(R.id.guncelsifre);
        yeniSifre=findViewById(R.id.yenisifre);
        yeniSifreTekrar=findViewById(R.id.yenisifretekrar);
        sifreDegistir=findViewById(R.id.sifredegis_sifredegis);
        sifreDegistir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (kontrol()){
                    sifreGuncelle(güncelSifre.getText().toString(),yeniSifre.getText().toString());
                    temizle();
                }
            }
        });
        blog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(SifreDegis.this,BlogYazilar.class);
                startActivity(intent);
                finish();
            }
        });
        kaydettarif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(SifreDegis.this,Tarifler.class);
                startActivity(intent);
                finish();
            }
        });
        bilgiler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(SifreDegis.this,BilgiSayfa.class);
                startActivity(intent);
                finish();
            }
        });
    }
    private boolean kontrol(){
        if (TextUtils.isEmpty(güncelSifre.getText().toString())) {
            // Toast.makeText(SifreDegis.this, "Eski Şifrenizi Giriniz!", Toast.LENGTH_SHORT).show();
            güncelSifre.setError("Eski şifrenizi giriniz!");
            return false;
        }
        if (yeniSifre.getText().toString().length() < 6) {
            yeniSifre.setError("Şifreniz en az 6 karakter olmalıdır!");
            //Toast.makeText(SifreDegis.this, "Yeni şifre en az 6 karakterden olışmalı!", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!yeniSifre.getText().toString().equals(yeniSifreTekrar.getText().toString())){
            yeniSifre.setError("Yeni şifreler farklı");
            yeniSifreTekrar.setError("Yeni şifreler farklı");
            return false;
        }
        return true;
    }
    private void sifreGuncelle(String oldPassword, String newPassword)
    {
        AuthCredential authCredential = EmailAuthProvider.getCredential(user.getEmail(), oldPassword);
        user.reauthenticate(authCredential).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                user.updatePassword(newPassword).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {


                        FirebaseFirestore.getInstance().collection("Users").document(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                .update("UPassword", newPassword);
                        Toast.makeText(SifreDegis.this, "Şifreniz güncellendi!", Toast.LENGTH_SHORT).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        Toast.makeText(SifreDegis.this, "Hata oluştu! ", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(SifreDegis.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }
    public void temizle(){
        güncelSifre.setText("");
        yeniSifreTekrar.setText("");
        yeniSifre.setText("");
    }
}