package com.example.yemektarif.Interface;

public interface EkledigimTariflerCall {
    public void onClickEkle(int i);
}
