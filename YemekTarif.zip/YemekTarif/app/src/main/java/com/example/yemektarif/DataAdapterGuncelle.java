package com.example.yemektarif;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.yemektarif.Interface.Callback;
import com.example.yemektarif.Interface.Guncelle;

import java.util.ArrayList;

public class DataAdapterGuncelle extends RecyclerView.Adapter<DataAdapterGuncelle.DataViewHolder> {
    Context context;
    ArrayList<YemekTarifleriDB>arrayList;
    Guncelle guncelle;

    public DataAdapterGuncelle(Context context, ArrayList<YemekTarifleriDB> arrayList, Guncelle guncelle) {
        this.context = context;
        this.arrayList = arrayList;
        this.guncelle=guncelle;
    }

    @NonNull
    @Override
    public DataViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View v = layoutInflater.inflate(R.layout.activity_tarif_detay,parent,false);
        return new DataViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull DataViewHolder holder, int position) {
        YemekTarifleriDB model = arrayList.get(position);
        Glide.with(context).load(model.getImageUrl()).into(holder.yemekfotosu);
        holder.yemekaditext.setText(model.getYemekadi());
        holder.yazartext.setText(model.getYazar());
        holder.yemekfotosu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guncelle.onClickGuncelle(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class DataViewHolder extends RecyclerView.ViewHolder{

        ImageView yemekfotosu;
        TextView yemekaditext, yazartext;
        public DataViewHolder(@NonNull View itemView) {
            super(itemView);
            yemekfotosu=itemView.findViewById(R.id.yemekfotosu);
            yemekaditext=itemView.findViewById(R.id.yemekaditext);
            yazartext=itemView.findViewById(R.id.yazaraditext);
        }
    }

    public void searchItem(ArrayList<YemekTarifleriDB> yemekTarifleriDBArrayList) {
        arrayList=yemekTarifleriDBArrayList;
        notifyDataSetChanged();
    }

}
