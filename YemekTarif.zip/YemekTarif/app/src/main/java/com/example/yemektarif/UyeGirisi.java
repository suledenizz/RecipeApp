package com.example.yemektarif;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class UyeGirisi extends AppCompatActivity {
    EditText sifre,mail;
    ImageButton girisYap,uyeOl;
    Users users;
    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore fstore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uye_girisi);
        users=new Users();
        mail=findViewById(R.id.emailedit);
        sifre=findViewById(R.id.sifre);
        firebaseAuth= FirebaseAuth.getInstance();
        fstore= FirebaseFirestore.getInstance();
    }


    public void sıgnIn(View view){

        firebaseAuth.signInWithEmailAndPassword(mail.getText().toString(),sifre.getText().toString()).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user.isEmailVerified()) {
                    Toast.makeText(UyeGirisi.this, Messages.girisBasarı, Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), BilgiSayfa.class));
                    finish();
                } else {
                    Toast.makeText(UyeGirisi.this, "Emailnizi Doğrulayınız!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), BilgiSayfa.class));
                    finish();
                }

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(UyeGirisi.this, "Kullanıcı Bulunamadı !", Toast.LENGTH_SHORT).show();

            }
        });
    }
    public void kayıtOlaGit(View view){
        Intent intent=new Intent(UyeGirisi.this,UyeOl.class);
        startActivity(intent);
        finish();
    }

    public void resetPassword(View view){
        Intent intent=new Intent(UyeGirisi.this,SifreUnuttum.class);
        startActivity(intent);
        finish();
    }
}