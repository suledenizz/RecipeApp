package com.example.yemektarif;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private ImageView a,b;
    private static int GECIS_SURESI=3000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        a=findViewById(R.id.girisicon);
        b=findViewById(R.id.giristext);
        Animation animation= AnimationUtils.loadAnimation(this,R.anim.animation);
        a.startAnimation(animation);
        b.startAnimation(animation);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent=new Intent(MainActivity.this, UyeGirisi.class);
                startActivity(intent);
                finish();
            }
        },GECIS_SURESI);
    }
}