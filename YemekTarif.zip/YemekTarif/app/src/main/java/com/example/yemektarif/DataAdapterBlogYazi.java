package com.example.yemektarif;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.yemektarif.Interface.Callback;

import java.util.ArrayList;

public class DataAdapterBlogYazi extends RecyclerView.Adapter<DataAdapterBlogYazi.DataViewHolder> {
    Context context;
    ArrayList<BlogYazilariDB>arrayList;
    Callback callback;

    public DataAdapterBlogYazi(Context context, ArrayList<BlogYazilariDB> arrayList, Callback callback) {
        this.context = context;
        this.arrayList = arrayList;
        this.callback=callback;
    }

    @NonNull
    @Override
    public DataViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View v = layoutInflater.inflate(R.layout.activity_blog_detay,parent,false);
        return new DataViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull DataViewHolder holder, int position) {
        BlogYazilariDB model = arrayList.get(position);
        Glide.with(context).load(model.getImageUrl()).into(holder.blogfotosu);
        holder.blogbasliktext.setText(model.getBaslik());
        holder.yazarblogtext.setText(model.getYazar());
        holder.blogfotosu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callback.onClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class DataViewHolder extends RecyclerView.ViewHolder{

        ImageView blogfotosu;
        TextView blogbasliktext, yazarblogtext;
        public DataViewHolder(@NonNull View itemView) {
            super(itemView);
            blogfotosu=itemView.findViewById(R.id.blogfotosu);
            blogbasliktext=itemView.findViewById(R.id.blogbasliktext);
            yazarblogtext=itemView.findViewById(R.id.yazaradiblogtext);
        }
    }

    public void searchItem(ArrayList<BlogYazilariDB> blogYazilariDBArrayList) {
        arrayList=blogYazilariDBArrayList;
        notifyDataSetChanged();
    }

}
