package com.example.yemektarif;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Adapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.bumptech.glide.load.model.stream.MediaStoreVideoThumbLoader;
import com.example.yemektarif.Interface.Callback;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Tarifler extends AppCompatActivity implements Callback {
    ImageButton  blog, kaydettarif, bilgiler;
    RecyclerView tariflersirali;
    ArrayList<YemekTarifleriDB>arrayList;
    ArrayList<String> keys;
    DataAdapter adapter;
    DatabaseReference databaseReference;
    ProgressDialog progressDialog;
    EditText araedit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tarifler);
        tariflersirali=findViewById(R.id.tariflersirali);
        tariflersirali.setLayoutManager(new LinearLayoutManager(this,RecyclerView.VERTICAL,false));
        tariflersirali.setHasFixedSize(true);
        arrayList=new ArrayList<>();
        keys=new ArrayList<>();
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Tarifler Yukleniyor...");
        araedit=findViewById(R.id.araedittext);
        databaseReference = FirebaseDatabase.getInstance().getReference("YemekTarif");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                arrayList.clear();
                for(DataSnapshot ds:snapshot.getChildren()){
                    YemekTarifleriDB yemekTarifleriDB = ds.getValue(YemekTarifleriDB.class);
                    arrayList.add(yemekTarifleriDB);
                    keys.add(ds.getKey());
                }
                adapter = new DataAdapter(Tarifler.this,arrayList,Tarifler.this);
                tariflersirali.setAdapter(adapter);
                progressDialog.dismiss();
            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Tarifler.this, "Hata"+ error.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        });

        araedit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String itemName = s.toString();
                ArrayList<YemekTarifleriDB>
                        yemekTarifleriDBArrayList=new ArrayList<>();
                for(YemekTarifleriDB ydb:arrayList){
                    if(ydb.getYemekadi().toLowerCase().contains(itemName)){
                        yemekTarifleriDBArrayList.add(ydb);
                    }
                    adapter.searchItem(yemekTarifleriDBArrayList);
                }
            }
        });
        blog=findViewById(R.id.tariflerblog);
        kaydettarif=findViewById(R.id.tariflertarifler);
        bilgiler=findViewById(R.id.tariflerbilgilerim);
        blog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Tarifler.this, BlogYazilar.class);
                startActivity(intent);
                finish();
            }
        });
        kaydettarif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Tarifler.this,Tarifler.class);
                startActivity(intent);
                finish();
            }
        });
        bilgiler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Tarifler.this,BilgiSayfa.class);
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    public void onClick(int i) {
        Intent intent = new Intent(Tarifler.this,TarifSayfasi.class);
        intent.putExtra("image",arrayList.get(i).getImageUrl());
        intent.putExtra("tarifadi",arrayList.get(i).getYemekadi());
        intent.putExtra("malzeme",arrayList.get(i).getMalzemeler());
        intent.putExtra("tarif",arrayList.get(i).getTarif());
        intent.putExtra("key",keys.get(i));
        System.out.println(keys.get(i)+"fjfj");
        startActivity(intent);
    }
}
