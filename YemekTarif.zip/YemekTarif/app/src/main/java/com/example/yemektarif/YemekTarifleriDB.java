package com.example.yemektarif;

public class YemekTarifleriDB {
    String yemekadi;
    String kategori;
    String malzemeler;
    String tarif;
    String yazar;
    String imageUrl;
    String key;
    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public YemekTarifleriDB(String yemekadi, String kategori, String malzemeler, String tarif, String yazar, String imageUrl) {
        this.yemekadi = yemekadi;
        this.kategori = kategori;
        this.malzemeler = malzemeler;
        this.tarif = tarif;
        this.yazar = yazar;
        this.imageUrl = imageUrl;
    }

    public YemekTarifleriDB() {
    }

    public String getYemekadi() {
        return yemekadi;
    }

    public void setYemekadi(String yemekadi) {
        this.yemekadi = yemekadi;
    }

    public String getKategori() {
        return kategori;
    }

    public void setKategori(String kategori) {
        this.kategori = kategori;
    }

    public String getMalzemeler() {
        return malzemeler;
    }

    public void setMalzemeler(String malzemeler) {
        this.malzemeler = malzemeler;
    }

    public String getTarif() {
        return tarif;
    }

    public void setTarif(String tarif) {
        this.tarif = tarif;
    }

    public String getYazar() {
        return yazar;
    }

    public void setYazar(String yazar) {
        this.yazar = yazar;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
