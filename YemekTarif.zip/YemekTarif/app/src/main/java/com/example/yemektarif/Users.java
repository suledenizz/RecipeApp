package com.example.yemektarif;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Users {
    private String  usermail;
    private String password;
    private String name;
    private String surname;
    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore fstore;



    public Users(){
        firebaseAuth=FirebaseAuth.getInstance();
        fstore=FirebaseFirestore.getInstance();
    }

    public  String SıgnIn(){

        final String[] message = {"null"};
        firebaseAuth.signInWithEmailAndPassword(usermail,password).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                FirebaseUser user=firebaseAuth.getCurrentUser();
message[0] ="Giriş Başarılı";
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
message[0] =e.getLocalizedMessage();
            }
        });
        return message[0];
    }

    public String SıgnUp(String isim,String soyisim,String usermail,String sifre){

        final String[] message = {null};
        firebaseAuth.createUserWithEmailAndPassword(usermail,sifre).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                FirebaseUser user=firebaseAuth.getCurrentUser();

                DocumentReference documentReference=fstore.collection("Users").document(user.getUid());
                Map<String,Object> userInfo=new HashMap<>();
                userInfo.put("FirstName",isim);
                userInfo.put("LastName",soyisim);
                userInfo.put("Email",usermail);
                userInfo.put("UPassword",sifre);
                documentReference.set(userInfo);
                message[0] ="Kayıt Başarıyla Gerçekleşti";
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
message[0] ="Kayıt Gerçekleşmedi,Bilgilerinizi Gözden Geçiriniz"+e.getLocalizedMessage();;
            }
        });
        return message[0];
    }
    public String getUsermail() {
        return usermail;
    }

    public void setUsermail(String usermail) {
        this.usermail = usermail;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }


}
