package com.example.yemektarif;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.core.TargetIdGenerator;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.text.DateFormat;
import java.util.Calendar;

public class TarifEkle extends AppCompatActivity {
    ImageButton kategori, blog, kaydettarif, bilgiler;
    EditText tarifadiedit, kategoriedit, malzemeleredit, hazirlanisedit, yazaredit;
    ImageView yemekfoto;
    Uri uri;
    String imageUrl;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tarif_ekle);
        blog=findViewById(R.id.blog_tarifekle);
        kaydettarif=findViewById(R.id.tarifler_tarifekle);
        bilgiler=findViewById(R.id.bilgiler_tarifekle);
        yemekfoto = findViewById(R.id.yemekresim);
        tarifadiedit=findViewById(R.id.tarifadieditsayfa);
        kategoriedit=findViewById(R.id.kategorieditsayfa);
        malzemeleredit=findViewById(R.id.malzemeeditsayfa);
        hazirlanisedit=findViewById(R.id.hazirlaniseditsayfa);
        yazaredit=findViewById(R.id.yazareditsayfa);
        blog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(TarifEkle.this,BlogYazilar.class);
                startActivity(intent);
                finish();
            }
        });
        kaydettarif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(TarifEkle.this,Tarifler.class);
                startActivity(intent);
                finish();
            }
        });
        bilgiler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(TarifEkle.this,BilgiSayfa.class);
                startActivity(intent);
                finish();
            }
        });
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},100);
        }
        else{
            Toast.makeText(this,"İzin Verilmedi!!",Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK){
            uri=data.getData();
            yemekfoto.setImageURI(uri);
        }
        else{
            Toast.makeText(this,"Resim Secmediniz!",Toast.LENGTH_SHORT).show();
        }
    }

    public void fotoSec(View view) {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent,1);
    }

    public void tarifyayimla(View view) {
        fotoEkle();
    }
    public void fotoEkle (){
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Fotograf Yukleniyor");
        progressDialog.show();
        StorageReference storageReference = FirebaseStorage.getInstance().getReference().child("YemekTarif").child(uri.getLastPathSegment());
        storageReference.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Task task =taskSnapshot.getStorage().getDownloadUrl();
                while (!task.isSuccessful());
                Uri urlImage =(Uri)task.getResult();
                imageUrl = urlImage.toString();
                tarifekle();
                progressDialog.dismiss();
                Toast.makeText(TarifEkle.this, "Fotograf Ekleme Basarili", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                progressDialog.dismiss();
                Toast.makeText(TarifEkle.this,"Hata"+e.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }
    public void tarifekle() {
        String yemekadi = tarifadiedit.getText().toString().trim();
        String kategori = kategoriedit.getText().toString().trim();
        String malzemeler = malzemeleredit.getText().toString().trim();
        String tarif = hazirlanisedit.getText().toString().trim();
        String yazar = yazaredit.getText().toString().trim();

        String timeStamp = DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());
        YemekTarifleriDB yemekTarifleriDB = new YemekTarifleriDB(yemekadi,kategori,malzemeler,tarif,yazar,imageUrl);
        FirebaseDatabase.getInstance().getReference("YemekTarif").child(timeStamp).setValue(yemekTarifleriDB).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(TarifEkle.this, "Hata"+e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}