package com.example.yemektarif;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class UyeOl extends AppCompatActivity {
    Users users;
    EditText ad,soyad,mail,sifre;
    ArrayList<EditText> texts;
    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore fstore;
    ImageButton uyeol, uyegiris;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uye_ol);
        firebaseAuth=FirebaseAuth.getInstance();
        fstore=FirebaseFirestore.getInstance();
        //  users=new Users();
        ad= findViewById(R.id.adedit);
        soyad=findViewById(R.id.soyadedit);
        mail=findViewById(R.id.emailedit_uye);
        sifre=findViewById(R.id.sifreedit_uyeol);
        textList();
        uyeol=findViewById(R.id.uyeol_uyeolbuton);
        uyegiris=findViewById(R.id.uyeol_uyegiris);
        uyegiris.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(UyeOl.this,UyeGirisi.class);
                startActivity(intent);
                finish();
            }
        });
        uyeol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if( kontrol(texts)){
                    firebaseAuth.createUserWithEmailAndPassword(mail.getText().toString(),sifre.getText().toString()).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                        @Override
                        public void onSuccess(AuthResult authResult) {
                            FirebaseUser user=firebaseAuth.getCurrentUser();

                            DocumentReference documentReference=fstore.collection("Users").document(user.getUid());
                            Map<String,Object> userInfo=new HashMap<>();
                            userInfo.put("FirstName",ad.getText().toString());
                            userInfo.put("LastName",soyad.getText().toString());
                            userInfo.put("Email",mail.getText().toString());
                            userInfo.put("UPassword",sifre.getText().toString());
                            documentReference.set(userInfo, SetOptions.merge());
                            user.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(UyeOl.this, "Giriş yapabilmek için " + Messages.mailBasarı, Toast.LENGTH_LONG).show();
                                        FirebaseAuth.getInstance().signOut();
                                        startActivity(new Intent(UyeOl.this, UyeGirisi.class));
                                        finish();
                                    } else {
                                        overridePendingTransition(0, 0);
                                        finish();
                                        overridePendingTransition(0, 0);
                                        startActivity(getIntent());

                                    }
                                }
                            });

                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(UyeOl.this,e.getLocalizedMessage(),Toast.LENGTH_LONG).show();
                        }
                    });
                    // String durum=users.SıgnUp(ad.getText().toString(),soyad.getText().toString(),mail.getText().toString(),sifre.getText().toString());

                }

            }
        });

    }

    private void textList() {
        texts=new ArrayList<>();
        texts.add(ad);
        texts.add(soyad);
        texts.add(sifre);
        texts.add(mail);
    }



    public boolean kontrol(ArrayList<EditText>editTexts){

        if ( sifre.getText().length()<6){
            sifre.setError("en az 6 karakter olmalıdır");
            return false;
        }

        for (EditText text:editTexts) {
            if(text.getText().toString().isEmpty()){
                text.setError("boş bırakılmaz");
                return false;
            }
        }
        return true;
    }
}