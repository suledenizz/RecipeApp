package com.example.yemektarif;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class BilgiSayfa extends AppCompatActivity {
    ImageButton tarifekle, ekledigimtarifler, blogyazisiekle, hesapbilgilerim, kategori, blog, kaydettarif, bilgiler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bilgi_sayfa);
        tarifekle=findViewById(R.id.tarifeklebilgiler);
        ekledigimtarifler=findViewById(R.id.ekledigimtarifler);
        blogyazisiekle=findViewById(R.id.blogyaziekle);
        hesapbilgilerim=findViewById(R.id.hesapbilgibuton);
        blog=findViewById(R.id.blog_bilgi);
        kaydettarif=findViewById(R.id.tarifler_bilgi);
        bilgiler=findViewById(R.id.bilgiler_bilgi);
        tarifekle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(BilgiSayfa.this,TarifEkle.class);
                startActivity(intent);
                finish();
            }
        });
        ekledigimtarifler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(BilgiSayfa.this,EkledigimTarifler.class);
                startActivity(intent);
                finish();
            }
        });
        blogyazisiekle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(BilgiSayfa.this,BlogYaziEkle.class);
                startActivity(intent);
                finish();
            }
        });
        hesapbilgilerim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(BilgiSayfa.this,Bilgilerim.class);
                startActivity(intent);
                finish();
            }
        });
        blog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(BilgiSayfa.this,BlogYazilar.class);
                startActivity(intent);
                finish();
            }
        });
        kaydettarif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(BilgiSayfa.this,Tarifler.class);
                startActivity(intent);
                finish();
            }
        });
        bilgiler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(BilgiSayfa.this,BilgiSayfa.class);
                startActivity(intent);
                finish();
            }
        });
    }
}