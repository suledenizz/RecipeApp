package com.example.yemektarif;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.text.DateFormat;
import java.util.Calendar;

public class BlogYaziEkle extends AppCompatActivity {
    ImageButton kategori, blog, kaydettarif, bilgiler;
    Uri uri;
    EditText baslikedit, yaziedit, yazaredit;
    ImageView blogresim;
    String imageUrl;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blog_yazi_ekle);
        blog=findViewById(R.id.blog_blogekle);
        kaydettarif=findViewById(R.id.tarifler_blogekle);
        bilgiler=findViewById(R.id.bilgiler_blogekle);
        baslikedit=findViewById(R.id.baslikeditblogekle);
        yaziedit=findViewById(R.id.yazieditblogekle);
        yazaredit=findViewById(R.id.yazareditblogekle);
        blogresim=findViewById(R.id.blogresimekle);
        blog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(BlogYaziEkle.this,BlogYazilar.class);
                startActivity(intent);
                finish();
            }
        });
        kaydettarif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(BlogYaziEkle.this,Tarifler.class);
                startActivity(intent);
                finish();
            }
        });
        bilgiler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(BlogYaziEkle.this,BilgiSayfa.class);
                startActivity(intent);
                finish();
            }
        });
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},100);
        }
        else{
            Toast.makeText(this,"İzin Verilmedi!!",Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK){
            uri=data.getData();
            blogresim.setImageURI(uri);
        }
        else{
            Toast.makeText(this,"Resim Secmediniz!",Toast.LENGTH_SHORT).show();
        }
    }
    public void fotoSecBlog(View view) {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent,1);
    }
    public void yaziyayimla(View view) {
        fotoEkle();
    }
    public void fotoEkle (){
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Fotograf Yukleniyor");
        progressDialog.show();
        StorageReference storageReference = FirebaseStorage.getInstance().getReference().child("YemekTarif").child(uri.getLastPathSegment());
        storageReference.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Task task =taskSnapshot.getStorage().getDownloadUrl();
                while (!task.isSuccessful());
                Uri urlImage =(Uri)task.getResult();
                imageUrl = urlImage.toString();
                yaziekle();
                progressDialog.dismiss();
                Toast.makeText(BlogYaziEkle.this, "Fotograf Ekleme Basarili", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                progressDialog.dismiss();
                Toast.makeText(BlogYaziEkle.this,"Hata"+e.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }
    public void yaziekle() {
        String baslik = baslikedit.getText().toString().trim();
        String yazi = yaziedit.getText().toString().trim();
        String yazar = yazaredit.getText().toString().trim();

        String timeStamp = DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());
        BlogYazilariDB blogYazilariDB = new BlogYazilariDB(baslik,yazi,yazar,imageUrl);
        FirebaseDatabase.getInstance().getReference("BlogYazi").child(timeStamp).setValue(blogYazilariDB).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(BlogYaziEkle.this, "Hata"+e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}