package com.example.yemektarif.Interface;

public interface Callback {
    public void onClick(int i);
}
