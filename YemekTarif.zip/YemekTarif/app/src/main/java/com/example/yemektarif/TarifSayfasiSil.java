package com.example.yemektarif;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.HashMap;

public class TarifSayfasiSil extends AppCompatActivity {
    ImageButton kategori, blog, kaydettarif, bilgiler;
    ImageView yemeginfotosu;
    TextView adtext, malzemetext, hazirlanistext,kategoritext;
    String imageUrl;
    String key;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tarif_sayfasi_sil);

        yemeginfotosu = findViewById(R.id.yemeginfotosusil);
        adtext = findViewById(R.id.basliktextsil);
        malzemetext = findViewById(R.id.malzemetextsil);
        hazirlanistext = findViewById(R.id.hazirlanistextsil);
        blog = findViewById(R.id.blog_tarifsayfasil);
        kaydettarif = findViewById(R.id.tarifler_tarifsayfasil);
        bilgiler = findViewById(R.id.bilgiler_tarifsayfasil);
        kategoritext=findViewById(R.id.kategoritextguncelle);
        Intent intent = getIntent();
        imageUrl = intent.getStringExtra("image");
        Glide.with(this).load(imageUrl).into(yemeginfotosu);
        key = intent.getStringExtra("key");
        malzemetext.setMovementMethod(new ScrollingMovementMethod());
        adtext.setMovementMethod(new ScrollingMovementMethod());
        hazirlanistext.setMovementMethod(new ScrollingMovementMethod());
        textleriDoldur();
        blog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TarifSayfasiSil.this, BlogYazilarGoruntule.class);
                startActivity(intent);
                finish();
            }
        });
        kaydettarif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TarifSayfasiSil.this, Tarifler.class);
                startActivity(intent);
                finish();
            }
        });
        bilgiler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TarifSayfasiSil.this, BilgiSayfa.class);
                startActivity(intent);
                finish();
            }
        });
    }

    public void tarifsil(View view) {
        final DatabaseReference reference = FirebaseDatabase.getInstance().getReference("YemekTarif");
        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference storageReference = storage.getReferenceFromUrl(imageUrl);
        storageReference.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                reference.child(key).removeValue();
                Toast.makeText(TarifSayfasiSil.this, "Tarif Başarıyla Silindi", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(TarifSayfasiSil.this, EkledigimTarifler.class));
                finish();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(TarifSayfasiSil.this, "Hata" + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }
    public void tarifguncellemeyap2(View view) {
        final DatabaseReference reference = FirebaseDatabase.getInstance().getReference("YemekTarif");
        String eskiTarif = hazirlanistext.getText().toString();
        View view1 = LayoutInflater.from(TarifSayfasiSil.this).inflate(R.layout.dialog_tarif, null);
        final EditText named = view1.findViewById(R.id.yenitarif);
        Button updateNameBtn = view1.findViewById(R.id.tarifdegis);
        named.setText(eskiTarif);
        final android.app.AlertDialog.Builder builder1 = new android.app.AlertDialog.Builder(TarifSayfasiSil.this);
        builder1.setView(view1);
        android.app.AlertDialog dialog = builder1.create();
        dialog.show();
        updateNameBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newRecipe = named.getText().toString();
                if (TextUtils.isEmpty(newRecipe))
                    return;
                HashMap hashMap = new HashMap();

                hashMap.put("tarif", newRecipe);
                reference.child(key).updateChildren(hashMap).addOnSuccessListener(new OnSuccessListener() {
                    @Override
                    public void onSuccess(Object o) {
                        hazirlanistext.setText(newRecipe);
                        Toast.makeText(TarifSayfasiSil.this, "başarı", Toast.LENGTH_LONG).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(TarifSayfasiSil.this, "hata", Toast.LENGTH_LONG).show();
                    }
                });
                dialog.dismiss();
                recreate();
            }
        });

    }
    public void tarifAdiGüncelle(View view) {
        final DatabaseReference reference = FirebaseDatabase.getInstance().getReference("YemekTarif");
        String eskiAd = adtext.getText().toString();
        View view1 = LayoutInflater.from(TarifSayfasiSil.this).inflate(R.layout.dialog_yemekadi, null);
        final EditText named = view1.findViewById(R.id.yeniyemekadi);
        Button updateNameBtn = view1.findViewById(R.id.yemekadidegis);
        named.setText(eskiAd);
        final android.app.AlertDialog.Builder builder1 = new android.app.AlertDialog.Builder(TarifSayfasiSil.this);
        builder1.setView(view1);
        android.app.AlertDialog dialog = builder1.create();
        dialog.show();
        updateNameBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newRecipe = named.getText().toString();
                if (TextUtils.isEmpty(newRecipe))
                    return;
                HashMap hashMap = new HashMap();

                hashMap.put("yemekadi", newRecipe);
                reference.child(key).updateChildren(hashMap).addOnSuccessListener(new OnSuccessListener() {
                    @Override
                    public void onSuccess(Object o) {
                        adtext.setText(newRecipe);
                        Toast.makeText(TarifSayfasiSil.this, "Tarif Adı Değiştirildi", Toast.LENGTH_LONG).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(TarifSayfasiSil.this, "Hata", Toast.LENGTH_LONG).show();
                    }
                });
                dialog.dismiss();
                recreate();
            }
        });
    }
    public void tarifYazarGüncelle(View view) {
        final DatabaseReference reference = FirebaseDatabase.getInstance().getReference("YemekTarif");
        String eskiAd = adtext.getText().toString();
        View view1 = LayoutInflater.from(TarifSayfasiSil.this).inflate(R.layout.dialog_yemekadi, null);
        final EditText named = view1.findViewById(R.id.yeniyemekadi);
        Button updateNameBtn = view1.findViewById(R.id.yemekadidegis);
        named.setText(eskiAd);
        final android.app.AlertDialog.Builder builder1 = new android.app.AlertDialog.Builder(TarifSayfasiSil.this);
        builder1.setView(view1);
        android.app.AlertDialog dialog = builder1.create();
        dialog.show();
        updateNameBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newRecipe = named.getText().toString();
                if (TextUtils.isEmpty(newRecipe))
                    return;
                HashMap hashMap = new HashMap();

                hashMap.put("yemekadi", newRecipe);
                reference.child(key).updateChildren(hashMap).addOnSuccessListener(new OnSuccessListener() {
                    @Override
                    public void onSuccess(Object o) {
                        Toast.makeText(TarifSayfasiSil.this, "başarı", Toast.LENGTH_LONG).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(TarifSayfasiSil.this, "hata", Toast.LENGTH_LONG).show();
                    }
                });
                dialog.dismiss();
                recreate();
            }
        });
    }
    public void tarifMalzemeGuncelle(View view) {
        final DatabaseReference reference = FirebaseDatabase.getInstance().getReference("YemekTarif");
        String eskiMalzeme= malzemetext.getText().toString();
        View view1 = LayoutInflater.from(TarifSayfasiSil.this).inflate(R.layout.dialog_malzemeler, null);
        final EditText named = view1.findViewById(R.id.yenimalzemeler);
        Button updateNameBtn = view1.findViewById(R.id.malzemedegis);
        named.setText(eskiMalzeme);
        final android.app.AlertDialog.Builder builder1 = new android.app.AlertDialog.Builder(TarifSayfasiSil.this);
        builder1.setView(view1);
        android.app.AlertDialog dialog = builder1.create();
        dialog.show();
        updateNameBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newRecipe = named.getText().toString();
                if (TextUtils.isEmpty(newRecipe))
                    return;
                HashMap hashMap = new HashMap();

                hashMap.put("malzemeler", newRecipe);
                reference.child(key).updateChildren(hashMap).addOnSuccessListener(new OnSuccessListener() {
                    @Override
                    public void onSuccess(Object o) {
                        malzemetext.setText(newRecipe);
                        Toast.makeText(TarifSayfasiSil.this, "Malzemeler Değiştirildi", Toast.LENGTH_LONG).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(TarifSayfasiSil.this, "Hata", Toast.LENGTH_LONG).show();
                    }
                });
                dialog.dismiss();
                recreate();
            }
        });
    }
    public void tarifKategoriGuncelle(View view) {
        final DatabaseReference reference = FirebaseDatabase.getInstance().getReference("YemekTarif");
        String eskiKategori= kategoritext.getText().toString();
        View view1 = LayoutInflater.from(TarifSayfasiSil.this).inflate(R.layout.dialog_kategoriguncelle, null);
        final EditText named = view1.findViewById(R.id.yenikategori);
        Button updateNameBtn = view1.findViewById(R.id.kategoridegis);
        named.setText(eskiKategori);
        final android.app.AlertDialog.Builder builder1 = new android.app.AlertDialog.Builder(TarifSayfasiSil.this);
        builder1.setView(view1);
        android.app.AlertDialog dialog = builder1.create();
        dialog.show();
        updateNameBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newRecipe = named.getText().toString();
                if (TextUtils.isEmpty(newRecipe))
                    return;
                HashMap hashMap = new HashMap();

                hashMap.put("kategori", newRecipe);
                reference.child(key).updateChildren(hashMap).addOnSuccessListener(new OnSuccessListener() {
                    @Override
                    public void onSuccess(Object o) {
                        kategoritext.setText(newRecipe);
                        Toast.makeText(TarifSayfasiSil.this, "Kategori Değiştirildi", Toast.LENGTH_LONG).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(TarifSayfasiSil.this, "Hata", Toast.LENGTH_LONG).show();
                    }
                });
                dialog.dismiss();
                recreate();
            }
        });
    }
    private void textleriDoldur(){
        final DatabaseReference reference = FirebaseDatabase.getInstance().getReference("YemekTarif").child(key);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                YemekTarifleriDB post = snapshot.getValue(YemekTarifleriDB.class);
                adtext.setText(post.getYemekadi());
                malzemetext.setText(post.getMalzemeler());
                hazirlanistext.setText(post.getTarif());
                kategoritext.setText(post.getKategori());
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }

    public void guncellemesaj(View view) {
        Toast.makeText(TarifSayfasiSil.this, "Güncelleme Yapmak İçin Yazıların Üstüne Basınız", Toast.LENGTH_LONG).show();
    }
}