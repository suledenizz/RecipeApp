package com.example.yemektarif.Interface;

public interface Guncelle {
    public void onClickGuncelle(int i);


}
