package com.example.yemektarif;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.yemektarif.Interface.CallbackEkledigim;
import com.example.yemektarif.Interface.EkledigimTariflerCall;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class EkledigimTarifler extends AppCompatActivity implements EkledigimTariflerCall, CallbackEkledigim {
    Button tarifsil, tarifguncelle;
    RecyclerView eklediklerim;
    ArrayList<YemekTarifleriDB>arrayList;
    DataAdapterEklediklerim adapter;
    DatabaseReference databaseReference;
    ProgressDialog progressDialog;
    EditText araedit;
    ImageButton blog, kaydettarif, bilgiler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ekledigim_tarifler);
        eklediklerim=findViewById(R.id.eklediklerim);
        blog=findViewById(R.id.ekledigimblog);
        kaydettarif=findViewById(R.id.ekledigimtarifsayfa);
        bilgiler=findViewById(R.id.ekledigimbilgilerim);
        blog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(EkledigimTarifler.this,BlogYazilar.class);
                startActivity(intent);
                finish();
            }
        });
        kaydettarif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(EkledigimTarifler.this,Tarifler.class);
                startActivity(intent);
                finish();
            }
        });
        bilgiler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(EkledigimTarifler.this,BilgiSayfa.class);
                startActivity(intent);
                finish();
            }
        });
        eklediklerim.setLayoutManager(new LinearLayoutManager(this,RecyclerView.VERTICAL,false));
        eklediklerim.setHasFixedSize(true);
        arrayList=new ArrayList<>();
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Tarifler Yukleniyor...");
        araedit=findViewById(R.id.araedittextekle);
        databaseReference = FirebaseDatabase.getInstance().getReference("YemekTarif");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                arrayList.clear();
                for(DataSnapshot ds:snapshot.getChildren()){
                    YemekTarifleriDB yemekTarifleriDB = ds.getValue(YemekTarifleriDB.class);
                    yemekTarifleriDB.setKey(ds.getKey());
                    arrayList.add(yemekTarifleriDB);
                }
                adapter = new DataAdapterEklediklerim(EkledigimTarifler.this,arrayList,EkledigimTarifler.this);
                eklediklerim.setAdapter(adapter);
                progressDialog.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(EkledigimTarifler.this, "Hata"+ error.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        });
        araedit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String itemName = s.toString();
                ArrayList<YemekTarifleriDB>yemekTarifleriDBArrayList=new ArrayList<>();
                for(YemekTarifleriDB ydb:arrayList){
                    if(ydb.getYemekadi().toLowerCase().contains(itemName)){
                        yemekTarifleriDBArrayList.add(ydb);
                    }
                    adapter.searchItem(yemekTarifleriDBArrayList);
                }
            }
        });
    }
    @Override
    public void onClickEkle(int i) {
        Intent intent = new Intent(EkledigimTarifler.this,TarifSayfasiSil.class);
        intent.putExtra("image",arrayList.get(i).getImageUrl());
        intent.putExtra("tarifadi",arrayList.get(i).getYemekadi());
        intent.putExtra("malzeme",arrayList.get(i).getMalzemeler());
        intent.putExtra("tarif",arrayList.get(i).getTarif());
        intent.putExtra("key",arrayList.get(i).getKey());
        startActivity(intent);
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

}