package com.example.yemektarif.Interface;

public interface CallbackEkledigim {
    public void onClickEkle(int i);
}
