package com.example.yemektarif;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class TarifSayfasi extends AppCompatActivity {
    ImageButton blog, kaydettarif, bilgiler;
    ImageView yemeginfotosu;
    TextView adtext, malzemetext, hazirlanistext,puanText;
    RatingBar ratingBar;
    String key;
    FirebaseUser user;
    int durum;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tarif_sayfasi);
        yemeginfotosu = findViewById(R.id.yemeginfotosu);
        adtext = findViewById(R.id.basliktext);
        malzemetext = findViewById(R.id.malzemetext);
        hazirlanistext = findViewById(R.id.hazirlanistext);
        blog = findViewById(R.id.blog_tarifsayfa);
        kaydettarif = findViewById(R.id.tarifler_tarifsayfa);
        bilgiler = findViewById(R.id.bilgiler_tarifsayfa);
        ratingBar = findViewById(R.id.ratingBar);
        Intent intent = getIntent();
        puanText=findViewById(R.id.puan);
        System.out.println(key);
        String imageUrl = intent.getStringExtra("image");
        Glide.with(this).load(imageUrl).into(yemeginfotosu);
        String yemekadi = intent.getStringExtra("tarifadi");
        adtext.setText(yemekadi);
        String malzemeler = intent.getStringExtra("malzeme");
        malzemetext.setText(malzemeler);
        key = intent.getStringExtra("key");
        String hazirlanis = intent.getStringExtra("tarif");
        hazirlanistext.setText(hazirlanis);
        malzemetext.setMovementMethod(new ScrollingMovementMethod());
        adtext.setMovementMethod(new ScrollingMovementMethod());
        hazirlanistext.setMovementMethod(new ScrollingMovementMethod());
        user = FirebaseAuth.getInstance().getCurrentUser();

        //ratingBar();
        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                HashMap hashMap = new HashMap();
                hashMap.put(user.getUid(), rating);
                final DatabaseReference reference = FirebaseDatabase.getInstance().getReference("YemekTarif").child(key).child("rating");
                reference.updateChildren(hashMap);
            }
        });
        final DatabaseReference reference = FirebaseDatabase.getInstance().getReference("YemekTarif").child(key).child("rating");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                float ratingsum = 0;
                float ratingAvg=0;
                float ratingTotal=0;
                for (DataSnapshot ds : snapshot.getChildren()) {
                    ratingsum = ratingsum + Float.parseFloat(ds.getValue().toString());
                    ratingTotal++;
                }
                if (ratingTotal!=0){
                    ratingAvg=ratingsum/ratingTotal;
                    puanText.setText("TARİF PUANI:"+ratingAvg);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        blog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TarifSayfasi.this, BlogYazilar.class);
                startActivity(intent);
                finish();
            }
        });
        kaydettarif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TarifSayfasi.this, Tarifler.class);
                startActivity(intent);
                finish();
            }
        });
        bilgiler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TarifSayfasi.this, BilgiSayfa.class);
                startActivity(intent);
                finish();
            }
        });
    }

}