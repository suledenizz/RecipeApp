package com.example.yemektarif;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.yemektarif.Interface.Callback;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class BlogYazilar extends AppCompatActivity implements Callback {
    ImageButton kategori, blog, kaydettarif, bilgiler;
    RecyclerView yazilarsirali;
    ArrayList<BlogYazilariDB> arrayList;
    DataAdapterBlogYazi adapter;
    DatabaseReference databaseReference;
    ProgressDialog progressDialog;
    EditText araedit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blog_yazilar);
        yazilarsirali=findViewById(R.id.yazilarsirali);
        yazilarsirali.setLayoutManager(new LinearLayoutManager(this,RecyclerView.VERTICAL,false));
        yazilarsirali.setHasFixedSize(true);
        arrayList=new ArrayList<>();
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Yazılar Yukleniyor...");
        araedit=findViewById(R.id.yaziara);
        databaseReference = FirebaseDatabase.getInstance().getReference("BlogYazi");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                arrayList.clear();
                for(DataSnapshot ds:snapshot.getChildren()){
                    BlogYazilariDB blogYazilariDB = ds.getValue(BlogYazilariDB.class);
                    arrayList.add(blogYazilariDB);
                }
                adapter = new DataAdapterBlogYazi(BlogYazilar.this,arrayList,BlogYazilar.this);
                yazilarsirali.setAdapter(adapter);
                progressDialog.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(BlogYazilar.this, "Hata"+ error.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }});
        araedit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String itemName = s.toString();
                ArrayList<BlogYazilariDB>blogYazilariDBArrayList=new ArrayList<>();
                for(BlogYazilariDB bdb:arrayList){
                    if(bdb.getBaslik().toLowerCase().contains(itemName)){
                        blogYazilariDBArrayList.add(bdb);
                    }
                    adapter.searchItem(blogYazilariDBArrayList);
                }
            }
        });
        blog=findViewById(R.id.blogyazilarblog);
        kaydettarif=findViewById(R.id.blogyazilartarifler);
        bilgiler=findViewById(R.id.blogyazilarbilgilerim);
        blog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(BlogYazilar.this,BlogYazilar.class);
                startActivity(intent);
                finish();
            }
        });
        kaydettarif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(BlogYazilar.this,Tarifler.class);
                startActivity(intent);
                finish();
            }
        });
        bilgiler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(BlogYazilar.this,BilgiSayfa.class);
                startActivity(intent);
                finish();
            }
        });
    }
    public void onClick(int i) {
        Intent intent = new Intent(BlogYazilar.this,BlogYazilarGoruntule.class);
        intent.putExtra("image",arrayList.get(i).getImageUrl());
        intent.putExtra("blogbaslik",arrayList.get(i).getBaslik());
        intent.putExtra("blogyazi",arrayList.get(i).getYazi());
        intent.putExtra("blogyazar",arrayList.get(i).getYazar());
        startActivity(intent);
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}