package com.example.yemektarif;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class SifreUnuttum extends AppCompatActivity {
    EditText emailedit;
    FirebaseAuth fAuth;
    ImageButton sendPasswordResetButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sifre_unuttum);
        emailedit=findViewById(R.id.emailedit_sifreunuttum);
        fAuth=FirebaseAuth.getInstance();
        sendPasswordResetButton=findViewById(R.id.imageButton7);
        sendPasswordResetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mail = emailedit.getText().toString().trim();
                if (mail.isEmpty()) {
                    emailedit.setError("Mail adresinizi giriniz");
                    emailedit.requestFocus();
                    return;
                }
                if (!Patterns.EMAIL_ADDRESS.matcher(mail).matches()) {
                    emailedit.setError("Geçerli  bir mail adresi giriniz! ");
                    emailedit.requestFocus();
                    return;
                }
                fAuth.sendPasswordResetEmail(mail).addOnCompleteListener(new OnCompleteListener<Void>() {

                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(SifreUnuttum.this, Messages.mailBasarı, Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(SifreUnuttum.this, Messages.mailHata, Toast.LENGTH_LONG).show();

                        }
                    }
                });
            }
        });
//
    }
    public void giriseGit(View view){
        Intent intent=new Intent(SifreUnuttum.this,UyeGirisi.class);
        startActivity(intent);
        finish();
    }

}