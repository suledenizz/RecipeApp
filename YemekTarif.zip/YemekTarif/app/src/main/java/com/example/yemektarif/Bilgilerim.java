package com.example.yemektarif;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Bilgilerim extends AppCompatActivity {
    FirebaseAuth firebaseAuth;
    TextView kullaniciAdi,kullaniciSoyadi;
    TextView kullaniciEmail,mailDogrulama;
    FirebaseUser user;
    private FirebaseAuth.AuthStateListener myAuthListener;
    @Override
    protected void onStart() {
        super.onStart();
        firebaseAuth.addAuthStateListener(myAuthListener);
    }
    ImageButton  kategori, blog, kaydettarif, bilgiler,sifreDegis;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bilgilerim);
        firebaseAuth = FirebaseAuth.getInstance();
        user = firebaseAuth.getCurrentUser();
        kullaniciAdi = findViewById(R.id.adtext);
        kullaniciEmail = findViewById(R.id.emailtext);
        kullaniciSoyadi=findViewById(R.id.soyadtext);
        blog=findViewById(R.id.blog_bilgilerim);
        kaydettarif=findViewById(R.id.tarifler_bilgilerim);
        bilgiler=findViewById(R.id.bilgiler_bilgilerim);
        sifreDegis=findViewById(R.id.sifredegis_sifredegis);
        mailDogrulama=findViewById(R.id.mailDogrula);
        sifreDegis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Bilgilerim.this,SifreDegis.class);
                startActivity(intent);
                finish();
            }
        });
        blog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Bilgilerim.this,BlogYazilar.class);
                startActivity(intent);
                finish();
            }
        });
        kaydettarif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Bilgilerim.this,Tarifler.class);
                startActivity(intent);
                finish();
            }
        });
        bilgiler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Bilgilerim.this,BilgiSayfa.class);
                startActivity(intent);
                finish();
            }
        });
        myAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if (user.isEmailVerified()){
                    System.out.println("burada");
                    mailDogrulama.setVisibility(View.INVISIBLE);
                }
                FirebaseFirestore.getInstance().collection("Users").document(user.getUid()).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot documentSnapshot = task.getResult();
                            if (documentSnapshot.exists()) {
                                Map<String, Object> userMap = documentSnapshot.getData();
                                for (Map.Entry<String, Object> entry : userMap.entrySet()) {
                                    if (entry.getKey().equals("FirstName")) {
                                        kullaniciAdi.setText(entry.getValue().toString());
                                    }
                                    if (entry.getKey().equals("LastName")) {
                                        kullaniciSoyadi.setText(entry.getValue().toString());
                                    }
                                }
                            } else {
                                Log.d("TAG", "No such document");
                            }
                        } else {
                            Log.d("TAG", "get failed with", task.getException());
                        }
                    }
                });
                kullaniciEmail.setText(user.getEmail());
                if (user.isEmailVerified()){
                    mailDogrulama.setClickable(false);
                    mailDogrulama.setVisibility(View.INVISIBLE);
                }else
                    mailDogrulama.setVisibility(View.VISIBLE);
                //  verEmail.setText(user.isEmailVerified() ? "Email adresiniz doğrulanmıştır." : "Email adresinizi doğrulayınız!");
            }

        };


    }

    public void userVerification(View view) {


        user.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(Bilgilerim.this, "Emailinizi kontrol ediniz.", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }


    public void updateUserLastName(View view) {
        String eskiAd = kullaniciSoyadi.getText().toString();

        View view1 = LayoutInflater.from(Bilgilerim.this).inflate(R.layout.dialog_soyisim_degistir, null);
        final EditText named = view1.findViewById(R.id.yenisoyad);
        Button updateNameBtn = view1.findViewById(R.id.DegistirBtn);
        named.setText(eskiAd);
        final android.app.AlertDialog.Builder builder1 = new android.app.AlertDialog.Builder(Bilgilerim.this);
        builder1.setView(view1);
        android.app.AlertDialog dialog = builder1.create();
        dialog.show();
        updateNameBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newName = named.getText().toString();
                if (TextUtils.isEmpty(newName))
                    return;
                FirebaseFirestore.getInstance().collection("Users").document(user.getUid())
                        .update("LastName", newName).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(Bilgilerim.this, "Kullanıcı soyadı başarıyla güncellendi.", Toast.LENGTH_SHORT).show();

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Bilgilerim.this, "Güncelleme başarısız!", Toast.LENGTH_SHORT).show();
                    }
                });
                dialog.dismiss();
                recreate();
            }
        });
    }
    public void updateUserEmailAddr(View view) {

        View view3 = LayoutInflater.from(Bilgilerim.this).inflate(R.layout.dialog_mail_degistir, null);
        final EditText newEmail = view3.findViewById(R.id.oldEmail);
        newEmail.setText(user.getEmail());
        Button updateEmailBtn = view3.findViewById(R.id.emailDegistirButon);

        final android.app.AlertDialog.Builder builder3 = new android.app.AlertDialog.Builder(Bilgilerim.this);
        builder3.setView(view3);
        android.app.AlertDialog dialog3 = builder3.create();
        dialog3.show();

        updateEmailBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

                if(newEmail.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(),"enter email address",Toast.LENGTH_SHORT).show();
                    return;
                }else {
                    if (Patterns.EMAIL_ADDRESS.matcher(newEmail.getText().toString()).matches()) {
                        Toast.makeText(getApplicationContext(),"valid email address",Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getApplicationContext(),"Invalid email address", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                user.updateEmail(newEmail.getText().toString()).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful())
                            Toast.makeText(Bilgilerim.this, "Emailininiz güncellendi.", Toast.LENGTH_SHORT).show();
                        recreate();
                    }

                });
            }
        });

    }
    public void updateUserFirstName(View v)
    {
        String eskiAd = kullaniciAdi.getText().toString();

        View view1 = LayoutInflater.from(Bilgilerim.this).inflate(R.layout.dialog_isim_degistir, null);
        final EditText named = view1.findViewById(R.id.isimNew);
        Button updateNameBtn = view1.findViewById(R.id.isimDegistirBtn);
        named.setText(eskiAd);
        final android.app.AlertDialog.Builder builder1 = new android.app.AlertDialog.Builder(Bilgilerim.this);
        builder1.setView(view1);
        android.app.AlertDialog dialog = builder1.create();
        dialog.show();
        updateNameBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newName = named.getText().toString();
                if (TextUtils.isEmpty(newName))
                    return;
                FirebaseFirestore.getInstance().collection("Users").document(user.getUid())
                        .update("FirstName", newName).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(Bilgilerim.this, "Kullanıcı adı başarıyla güncellendi.", Toast.LENGTH_SHORT).show();

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Bilgilerim.this, "Güncelleme başarısız!", Toast.LENGTH_SHORT).show();
                    }
                });
                dialog.dismiss();
                recreate();
            }
        });
    }

    public void cıkısButon(View v){
        firebaseAuth.signOut();
        Intent intent=new Intent(Bilgilerim.this,UyeGirisi.class);
        startActivity(intent);
        finish();
    }
}