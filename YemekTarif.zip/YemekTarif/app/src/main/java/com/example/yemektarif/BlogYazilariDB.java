package com.example.yemektarif;

public class BlogYazilariDB {
    String baslik;
    String yazi;
    String yazar;
    String imageUrl;
    String key;
    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }



    public BlogYazilariDB(String baslik, String yazi, String yazar, String imageUrl) {
        this.baslik = baslik;
        this.yazi = yazi;
        this.yazar = yazar;
        this.imageUrl = imageUrl;
    }

    public BlogYazilariDB() {
    }

    public String getBaslik() {
        return baslik;
    }

    public void setBaslik(String baslik) {
        this.baslik = baslik;
    }

    public String getYazi() {
        return yazi;
    }

    public void setYazi(String yazi) {
        this.yazi = yazi;
    }

    public String getYazar() {
        return yazar;
    }

    public void setYazar(String yazar) {
        this.yazar = yazar;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
