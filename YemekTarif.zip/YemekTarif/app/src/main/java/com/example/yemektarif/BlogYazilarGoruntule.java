package com.example.yemektarif;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class BlogYazilarGoruntule extends AppCompatActivity {
    ImageButton kategori, blog, kaydettarif, bilgiler;
    ImageView blogfotogoruntule;
    TextView blogyazibaslikgor, blogyazigor, blogyazargor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blog_yazilar_goruntule);
        blog=findViewById(R.id.blog_blogsayfa);
        kaydettarif=findViewById(R.id.tarifler_blogsayfa);
        bilgiler=findViewById(R.id.bilgiler_blogsayfa);
        blogfotogoruntule=findViewById(R.id.blogresimgoruntule);
        blogyazibaslikgor=findViewById(R.id.blogbaslik);
        blogyazigor=findViewById(R.id.blogyazigoruntule);
        blogyazargor=findViewById(R.id.blogyazargoruntule);

        Intent intent =getIntent();
        String imageUrl = intent.getStringExtra("image");
        Glide.with(this).load(imageUrl).into(blogfotogoruntule);
        String baslik = intent.getStringExtra("blogbaslik");
        blogyazibaslikgor.setText(baslik);
        String yazi = intent.getStringExtra("blogyazi");
        blogyazigor.setText(yazi);
        String yazar = intent.getStringExtra("blogyazar");
        blogyazargor.setText(yazar);
        blogyazibaslikgor.setMovementMethod(new ScrollingMovementMethod());
        blogyazigor.setMovementMethod(new ScrollingMovementMethod());
        blogyazargor.setMovementMethod(new ScrollingMovementMethod());
        blog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(BlogYazilarGoruntule.this,BlogYazilar.class);
                startActivity(intent);
                finish();
            }
        });
        kaydettarif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(BlogYazilarGoruntule.this,Tarifler.class);
                startActivity(intent);
                finish();
            }
        });
        bilgiler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(BlogYazilarGoruntule.this,BilgiSayfa.class);
                startActivity(intent);
                finish();
            }
        });
    }
}